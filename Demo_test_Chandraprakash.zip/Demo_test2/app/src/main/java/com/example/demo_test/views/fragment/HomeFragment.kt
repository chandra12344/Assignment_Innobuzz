package com.example.demo_test.views.fragment

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.demo_test.R
import com.example.demo_test.dataModels.ResData
import com.example.demo_test.databinding.FragmentHomeBinding
import com.example.demo_test.network.ApiInterface
import com.example.demo_test.network.RetrofitInstance
import com.example.demo_test.views.adapter.ItemAdapter
import com.example.room.mvvm.viewmodel.MyViewModel
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class HomeFragment : Fragment() {
    lateinit var binding: FragmentHomeBinding
    lateinit var myViewModel: MyViewModel
    lateinit var myAdapter: ItemAdapter
    var listData=ArrayList<ResData>()
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        binding=FragmentHomeBinding.inflate(layoutInflater)
        initview()
        getData()
        return binding.root
    }
    private fun initview() {
        myViewModel = ViewModelProvider(this).get(MyViewModel::class.java)
        binding.rec.layoutManager = LinearLayoutManager(activity)
        myAdapter = ItemAdapter(listData)
        binding.rec.adapter = myAdapter
        myAdapter.setOnClickListener(object :
            ItemAdapter.OnClickListener {
            override fun onClick(position: Int, model: ResData) {
                setFragment(BodyFragment(model.title,model.body))
//                Toast.makeText(activity, "${model.title}", Toast.LENGTH_SHORT).show()
            }
        })
    }
    private fun setFragment(fragment: Fragment){
        activity?.supportFragmentManager?.beginTransaction()?.replace(R.id.framlayout, fragment)?.commit()
    }
    fun getData(){
        val apiInterface = RetrofitInstance.getInstance().create(ApiInterface::class.java)
        val call: Call<ArrayList<ResData>> =apiInterface.getData()
        call.enqueue(object: Callback<ArrayList<ResData>> {
            override fun onResponse(call: Call<ArrayList<ResData>>, response: Response<ArrayList<ResData>>) {
                listData.addAll(response.body()!!)
                myAdapter.notifyDataSetChanged()
                for (i in listData) {
//                    myViewModel.insertData(this@MainActivity,"","","")
                }
            }
            override fun onFailure(call: Call<ArrayList<ResData>>, t: Throwable) {
//                Toast.makeText(activity, "failed", Toast.LENGTH_SHORT).show()

            }
        })
    }
}