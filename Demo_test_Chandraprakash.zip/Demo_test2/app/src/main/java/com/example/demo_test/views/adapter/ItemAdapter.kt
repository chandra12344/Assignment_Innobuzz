package com.example.demo_test.views.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.demo_test.dataModels.ResData
import com.example.demo_test.databinding.LayoutViewDesignBinding

class ItemAdapter(private val items: ArrayList<ResData>):
	RecyclerView.Adapter<ItemAdapter.ViewHolder>() {
	private var onClickListener: OnClickListener? = null
	override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
		return ViewHolder(LayoutViewDesignBinding.inflate(LayoutInflater.from(parent.context), parent, false)
		)
	}
	override fun onBindViewHolder(holder: ViewHolder, position: Int) {
		val item = items[position]
		holder.tvName.text = "${item.id}. "+item.title
		holder.itemView.setOnClickListener {
			if (onClickListener != null) {
				onClickListener!!.onClick(position, item )
			}
		}
	}
	override fun getItemCount(): Int {
		return items.size
	}
	fun setOnClickListener(onClickListener: OnClickListener) {
		this.onClickListener = onClickListener
	}
	interface OnClickListener {
		fun onClick(position: Int, model: ResData)
	}
	class ViewHolder(binding: LayoutViewDesignBinding) : RecyclerView.ViewHolder(binding.root) {
		val tvName = binding.textView
	}
}
