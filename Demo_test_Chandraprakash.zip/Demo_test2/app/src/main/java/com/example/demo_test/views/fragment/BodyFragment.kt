package com.example.demo_test.views.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.demo_test.R
import com.example.demo_test.databinding.FragmentBodyBinding

class BodyFragment(title: String?, body: String?) : Fragment() {
    var title = title
    var body = body
    lateinit var binding: FragmentBodyBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentBodyBinding.inflate(layoutInflater)
        binding.title.text =title
        binding.body.text =body
        binding.back.setOnClickListener{
            setFragment(HomeFragment())
        }
            return binding.root
    }
    private fun setFragment(fragment: Fragment){
        activity?.supportFragmentManager?.beginTransaction()?.replace(R.id.framlayout, fragment)?.commit()
    }
}