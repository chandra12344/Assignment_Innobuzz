package com.example.room.mvvm.repository

import android.content.Context
import androidx.lifecycle.LiveData
import com.example.demo_test.roomDatabase.DataTableModel
import com.example.room.mvvm.room.TestDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers.IO
import kotlinx.coroutines.launch

class DataRepository {
    companion object {
        var loginDatabase: TestDatabase? = null
        var dataTableModel: LiveData<List<DataTableModel>>? = null

        fun initializeDB(context: Context) : TestDatabase {
            return TestDatabase.getDataseClient(context)
        }
        fun insertData(context: Context, userId: String, title: String,body: String) {
            loginDatabase = initializeDB(context)
            CoroutineScope(IO).launch {
                val loginDetails = DataTableModel(userId, title,body)
                loginDatabase!!.testDao().InsertData(loginDetails)
            }
        }
        fun getLoginDetails(context: Context) : LiveData<List<DataTableModel>>? {
            loginDatabase = initializeDB(context)
            dataTableModel = loginDatabase!!.testDao().getDetails()
            return dataTableModel
        }
        fun deleteAll(context: Context){
            loginDatabase = initializeDB(context)
            loginDatabase!!.testDao().deleteAll()
        }

    }
}