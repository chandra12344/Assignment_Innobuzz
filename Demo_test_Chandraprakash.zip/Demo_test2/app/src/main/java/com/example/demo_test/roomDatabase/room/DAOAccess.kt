package com.example.room.mvvm.room

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.demo_test.roomDatabase.DataTableModel

@Dao
interface DAOAccess {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun InsertData(dataTableModel: DataTableModel)

    @Query("SELECT * FROM TableData")
   fun getDetails() : LiveData<List<DataTableModel>>

    @Query("DELETE FROM TableData")
    fun deleteAll()

}