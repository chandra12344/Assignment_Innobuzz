package com.example.room.mvvm.viewmodel

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.example.demo_test.roomDatabase.DataTableModel
import com.example.room.mvvm.repository.DataRepository

class MyViewModel : ViewModel() {
    var liveData: LiveData<List<DataTableModel>>? = null
    fun insertData(context: Context, userId: String, title: String,body:String) {
       DataRepository.insertData(context, userId, title,body)
    }
    fun getData(context: Context) : LiveData<List<DataTableModel>>? {
        liveData = DataRepository.getLoginDetails(context)
        return liveData
    }
    fun deleteAllData(context: Context){
        DataRepository.deleteAll(context)
    }

}