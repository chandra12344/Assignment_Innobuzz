package com.example.demo_test.views.activity

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.demo_test.R
import com.example.demo_test.dataModels.ResData
import com.example.demo_test.databinding.ActivityMainBinding
import com.example.demo_test.network.ApiInterface
import com.example.demo_test.network.RetrofitInstance
import com.example.demo_test.views.adapter.ItemAdapter
import com.example.demo_test.views.fragment.HomeFragment
import com.example.room.mvvm.viewmodel.MyViewModel
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding
    var listData=ArrayList<ResData>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding=ActivityMainBinding.inflate(layoutInflater)
        setFragment(HomeFragment())
        setContentView(binding.root)
    }
    private fun setFragment(fragment: Fragment){
        supportFragmentManager.beginTransaction().replace(R.id.framlayout, fragment).commit()
    }

}