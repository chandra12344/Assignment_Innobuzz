package com.example.room.mvvm.room

import android.content.Context
import androidx.room.*
import com.example.demo_test.roomDatabase.DataTableModel

@Database(entities = arrayOf(DataTableModel::class), version = 1, exportSchema = false)
abstract class TestDatabase : RoomDatabase() {
    abstract fun testDao() : DAOAccess
    companion object {
        @Volatile
        private var INSTANCE:TestDatabase? = null
        fun getDataseClient(context: Context) :TestDatabase {

            if (INSTANCE != null) return INSTANCE!!

            synchronized(this) {

                INSTANCE = Room
                    .databaseBuilder(context,TestDatabase::class.java, "TEST_DATABASE")
                    .fallbackToDestructiveMigration()
                    .build()

                return INSTANCE!!

            }
        }

    }

}